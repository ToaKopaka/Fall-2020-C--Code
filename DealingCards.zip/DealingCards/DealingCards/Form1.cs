﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DealingCards
{
    public partial class Form1 : Form
    {

        List<Card> hand = new List<Card>();
        List<Card> deck = new List<Card>();
        Random random = new Random();

        public Form1()
        {
            InitializeComponent();


            for (int suit = 0; suit <= 3; suit++)
                for (int value = 1; value <= 13; value++)
                    deck.Add(new Card((Suits)suit, (Values)value));

           
            for(int i = 0; i < deck.Count(); i++)
            {
                DeckBox.Items.Add(deck.ElementAt(i).ToString());
            }
            

        }

        private void DrawBtn_Click(object sender, EventArgs e)
        {
            if(deck.Count() != 0){
                int index = random.Next(deck.Count());

                hand.Add(deck[index]);
                deck.RemoveAt(index);

                DeckBox.Items.Clear();

                for (int i = 0; i < deck.Count(); i++)
                {
                    DeckBox.Items.Add(deck.ElementAt(i).ToString());
                }

                HandBox.Items.Clear();
                for (int i = 0; i < hand.Count(); i++)
                {
                    HandBox.Items.Add(hand.ElementAt(i).ToString());
                }


            }
            else
            {
                MessageBox.Show("The deck is empty");
            }



        }

        private void SortBtn_Click(object sender, EventArgs e)
        {
            hand.Sort();
            HandBox.Items.Clear();
            for (int i = 0; i < hand.Count(); i++)
            {
                HandBox.Items.Add(hand.ElementAt(i).ToString());
            }

        }
    }
}
