﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DealingCards 
{
    enum Suits
    {
        Spades,
        Clubs,
        Diamonds,
        Hearts
    }

    enum Values
    {
        Ace = 1,
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        Ten = 10,
        Jack = 11,
        Queen = 12,
        King = 13
    }

    class Card : IComparable<Card>
    {
        public Suits Suit { get; set; }
        public Values Value { get; set; }
        
        public Card(Suits Suit, Values Value)
        {
            this.Suit = Suit;
            this.Value = Value;
        }

        /* public String Name
        {
            get { return Value.ToString() + " of " + Suit.ToString(); }
        }*/

        public int CompareTo(Card other)
        {
            //return +1 if value is higher than other 
            //return 0 in the values is the 
            //return -1 if the value is lower than other card
            if(this.Value > other.Value)
            {
                return 1;
            }else if (this.Value < other.Value)
            {
                return -1;
            }
            else
            {
                return 0;
            }


        }

        public override string ToString()
        {
            return Value.ToString() + " of " + Suit.ToString();
        }
    }
}
